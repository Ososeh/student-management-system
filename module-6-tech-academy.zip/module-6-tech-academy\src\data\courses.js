// Store the course records in one reusable data file so page components do not duplicate course information.
const courses = [
  {
    id: 1,
    title: "ReactJS Development",
    category: "Frontend",
    level: "Beginner",
    duration: "12 weeks",
    instructor: "Sarah Johnson",
    price: "₦350,000",
    description: "Learn React fundamentals, components, state, hooks, routing, forms, and API integration.",
    topics: ["Components and Props", "State and Events", "React Hooks", "React Router", "Forms", "API Integration"],
  },
  {
    id: 2,
    title: "JavaScript Fundamentals",
    category: "Programming",
    level: "Beginner",
    duration: "8 weeks",
    instructor: "David James",
    price: "₦250,000",
    description: "Build a strong JavaScript foundation through practical exercises and projects.",
    topics: ["Variables", "Functions", "Arrays", "Objects", "DOM", "Async JavaScript"],
  },
  {
    id: 3,
    title: "Full-Stack Web Engineering",
    category: "Full Stack",
    level: "Intermediate",
    duration: "16 weeks",
    instructor: "Michael Brown",
    price: "₦500,000",
    description: "Learn how frontend applications communicate with backend services and databases.",
    topics: ["React", "Node.js", "REST APIs", "Databases", "Authentication", "Deployment"],
  },
  {
    id: 4,
    title: "UI/UX Design Essentials",
    category: "Design",
    level: "Intermediate",
    duration: "10 weeks",
    instructor: "Grace Williams",
    price: "₦300,000",
    description: "Learn practical interface and user-experience design for modern digital products.",
    topics: ["User Research", "Wireframes", "Prototyping", "Design Systems", "Accessibility", "Usability"],
  },
];

// Export the data so course pages and reusable cards can import the same source.
export default courses;
