// Import useSearchParams so the selected course level lives in the URL.
import { useSearchParams } from "react-router";
// Import the reusable course card.
import CourseCard from "../components/CourseCard";
// Import the course data.
import courses from "../data/courses";

// Create the course listing page.
function Courses() {
  // Read and update query parameters.
  const [searchParams, setSearchParams] = useSearchParams();
  // Read the level from the URL or use "all" when no filter exists.
  const selectedLevel = searchParams.get("level") || "all";
  // Filter the course data according to the URL value.
  const filteredCourses = selectedLevel === "all" ? courses : courses.filter((course) => course.level.toLowerCase() === selectedLevel);
  // Change the query parameter when the learner chooses a filter.
  const changeLevel = (level) => { if (level === "all") { setSearchParams({}); return; } setSearchParams({ level }); };

  // Render the course page.
  return (
    <main className="section">
      <p className="eyebrow">Available Programmes</p>
      <h1>Explore Our Courses</h1>
      <div className="filter-buttons">
        <button className={selectedLevel === "all" ? "active" : ""} onClick={() => changeLevel("all")}>All</button>
        <button className={selectedLevel === "beginner" ? "active" : ""} onClick={() => changeLevel("beginner")}>Beginner</button>
        <button className={selectedLevel === "intermediate" ? "active" : ""} onClick={() => changeLevel("intermediate")}>Intermediate</button>
      </div>
      {filteredCourses.length > 0 ? <div className="course-grid">{filteredCourses.map((course) => <CourseCard key={course.id} course={course} />)}</div> : <p className="empty-message">No courses match this filter.</p>}
    </main>
  );
}

// Export the course page.
export default Courses;
