# Module 6 Mini-Project Correction Report

## Problems identified

- The original login form redirected to the dashboard without checking an account.
- There was no signup flow.
- The dashboard route was not protected.
- The dashboard displayed hard-coded student information and statistics.
- The profile page displayed hard-coded name, initials, and email values.
- Course progress was hard-coded rather than stored per user and per course.
- Course enrollment did not create a persistent enrollment record.
- Logout only navigated to `/login`; it did not clear an authentication session.
- The root URL opened the public Home page instead of requiring authentication first.

## Corrections

- Added a signup/login flow with first name, last name, email, password, and password confirmation.
- Added an authentication context and account service.
- Added a dedicated `navigation/` folder containing `ProtectedRoute.jsx`, `StartRedirect.jsx`, and `AppNavigation.jsx`.
- Protected the complete dashboard route tree.
- Added a root redirect: signed-out users go to `/login`; authenticated users go to `/dashboard`.
- Replaced hard-coded dashboard identity/statistics with values calculated from the signed-in account.
- Replaced hard-coded profile information with the current account's first name, last name, full name, initials, and email.
- Added independent enrollment records for each course.
- New enrollments start at `0%` and `completed: false`.
- Added a `Mark as Complete` action that changes only the selected course to `100%` and `completed: true`.
- Persisted account and course-progress records in browser storage so they survive refreshes and logout/login cycles.
- Kept the existing visual design and added only small styles needed for authentication and progress states.
- Preserved `App.jsx` as a route-configuration file rather than moving application UI into it.

## Testing performed

Static checks were run against the complete source tree to verify:

- All imported local files exist.
- All expected authentication, navigation, layout, page, and data files exist.
- Dashboard routes are nested under the protected route.
- The root route uses the startup redirect.
- The dashboard uses `Outlet` for nested pages.
- Dynamic course routing uses `useParams`.
- Course filtering uses `useSearchParams`.
- Login/signup uses the authentication context.
- Enrollment starts at zero progress.
- Completion sets only the selected course to 100%.
- Profile information comes from the authenticated account rather than placeholder text.

The environment did not have the project's npm dependencies available, and repeated `npm install` attempts exceeded the execution timeout. Therefore a live Vite build, ESLint run, and browser-console test could not honestly be reported as passed in this environment. The corrected source was inspected and statically validated instead.

## Important security note

This is a frontend learning project. Its account records are stored in browser storage and passwords are stored in the demo account object. That is suitable only for practicing React state, routing, and persistence. A production authentication system must use a backend, secure password hashing, secure session/token handling, and server-side authorization.


## Deployment routing correction

- Confirmed that the original project contained neither `.htaccess` nor `vercel.json`.
- Added `vercel.json` with a catch-all rewrite to `/index.html` for Vercel SPA routing. This prevents direct navigation/refreshes of client-side React Router URLs from being treated as missing server files.
- Added `public/.htaccess` as an Apache/cPanel compatibility file. It is not used by Vercel.
- The application continues to use `BrowserRouter`; no hash-based routing was introduced.
