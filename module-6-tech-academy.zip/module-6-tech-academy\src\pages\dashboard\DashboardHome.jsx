// Import the authenticated account and course data.
import { useAuth } from "../../auth/AuthContext";
import courses from "../../data/courses";

// Create the dashboard overview page.
function DashboardHome() {
  // Read the currently signed-in student.
  const { user } = useAuth();
  // Turn the saved course object into an array for calculations.
  const enrolledCourses = Object.entries(user.enrolledCourses);
  // Count courses that have reached 100 percent.
  const completedCourses = enrolledCourses.filter(([, progress]) => progress.completed).length;
  // Calculate average progress across the student's enrolled courses.
  const overallProgress = enrolledCourses.length === 0 ? 0 : Math.round(enrolledCourses.reduce((total, [, progress]) => total + progress.progress, 0) / enrolledCourses.length);

  // Return the student's personalised dashboard summary.
  return (
    <div>
      <p className="eyebrow">Dashboard</p>
      <h1>Welcome Back, {user.firstName} {user.lastName}</h1>
      <p>Continue learning and monitor your course progress.</p>
      <div className="statistics-grid">
        <article><strong>{enrolledCourses.length}</strong><span>Enrolled Courses</span></article>
        <article><strong>{completedCourses}</strong><span>Completed Courses</span></article>
        <article><strong>{overallProgress}%</strong><span>Overall Progress</span></article>
      </div>
      <section className="content-section">
        <h2>Your Learning</h2>
        {enrolledCourses.length === 0 ? <p>No courses enrolled yet. Visit the Courses page to begin learning.</p> : <ul>{enrolledCourses.map(([courseId, progress]) => <li key={courseId}>{courses.find((course) => course.id === Number(courseId))?.title}: {progress.progress}%</li>)}</ul>}
      </section>
    </div>
  );
}

// Export the dashboard home.
export default DashboardHome;
