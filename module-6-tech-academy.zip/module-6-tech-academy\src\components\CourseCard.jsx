// Import Link so a course card can navigate to its dynamic details URL without a full page reload.
import { Link } from "react-router";

// Receive one course object through props and display its main information.
function CourseCard({ course }) {
  // Return one reusable course card.
  return (
    <article className="course-card">
      <div className="course-card-header"><span>{course.category}</span><span>{course.level}</span></div>
      <h2>{course.title}</h2>
      <p>{course.description}</p>
      <div className="course-meta"><span>{course.duration}</span><span>{course.price}</span></div>
      <Link to={`/courses/${course.id}`} className="primary-button">View Course</Link>
    </article>
  );
}

// Export the reusable card.
export default CourseCard;
