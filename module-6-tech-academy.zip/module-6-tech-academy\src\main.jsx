// Import React's StrictMode for helpful development checks.
import { StrictMode } from "react";
// Import createRoot so React can attach the application to the browser DOM.
import { createRoot } from "react-dom/client";
// Import BrowserRouter because the project uses browser-based client-side routing.
import { BrowserRouter } from "react-router";
// Import the authentication provider so every route can access the current account.
import { AuthProvider } from "./auth/AuthContext";
// Import the main application component.
import App from "./App";
// Import the global stylesheet.
import "./index.css";

// Find the HTML element whose id is "root".
const rootElement = document.getElementById("root");
// Create the React root and provide routing and authentication to the entire application.
createRoot(rootElement).render(
  <StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <App />
      </AuthProvider>
    </BrowserRouter>
  </StrictMode>,
);
