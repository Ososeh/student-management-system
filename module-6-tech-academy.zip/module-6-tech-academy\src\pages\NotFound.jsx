// Import Link so the user can return to the home page.
import { Link } from "react-router";

// Create the custom wildcard 404 page.
function NotFound() {
  // Return a friendly error page.
  return <main className="not-found-page"><p className="error-code">404</p><h1>Page Not Found</h1><p>We could not find the page you requested.</p><Link to="/home" className="primary-button">Return to Home</Link></main>;
}

// Export the 404 page.
export default NotFound;
