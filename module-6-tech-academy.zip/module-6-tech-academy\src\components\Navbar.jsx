// Import the navigation component that contains the authentication-aware menu.
import AppNavigation from "../navigation/AppNavigation";

// Keep Navbar as the component used by the existing PublicLayout structure.
function Navbar() {
  // Render the dedicated navigation component.
  return <AppNavigation />;
}

// Export the shared navigation wrapper.
export default Navbar;
