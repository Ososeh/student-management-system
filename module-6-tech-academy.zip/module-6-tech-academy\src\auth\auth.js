// Store all demo account records under one browser key so the practice project can remember accounts after refreshes.
const ACCOUNTS_KEY = "tech-academy-accounts";
// Store the currently signed-in account separately so protected routes can identify the active user.
const SESSION_KEY = "tech-academy-session";

// Read the saved account object from browser storage.
function readAccounts() {
  const savedAccounts = localStorage.getItem(ACCOUNTS_KEY);
  if (!savedAccounts) return {};
  try {
    return JSON.parse(savedAccounts);
  } catch (error) {
    console.error("Could not read saved accounts:", error);
    return {};
  }
}

// Save the complete account object back to browser storage.
function saveAccounts(accounts) {
  localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
}

// Create a new account and give it an empty enrolled-course list.
export function signUp({ firstName, lastName, email, password }) {
  const accounts = readAccounts();
  const normalizedEmail = email.trim().toLowerCase();
  if (accounts[normalizedEmail]) {
    throw new Error("An account with this email already exists.");
  }

  const account = {
    firstName: firstName.trim(),
    lastName: lastName.trim(),
    email: normalizedEmail,
    password,
    enrolledCourses: {},
  };

  accounts[normalizedEmail] = account;
  saveAccounts(accounts);
  localStorage.setItem(SESSION_KEY, normalizedEmail);
  console.log("Account created for:", normalizedEmail);
  return account;
}

// Check the supplied email and password against the saved demo account object.
export function login(email, password) {
  const accounts = readAccounts();
  const normalizedEmail = email.trim().toLowerCase();
  const account = accounts[normalizedEmail];

  if (!account || account.password !== password) {
    throw new Error("The email or password is incorrect.");
  }

  localStorage.setItem(SESSION_KEY, normalizedEmail);
  console.log("User logged in:", normalizedEmail);
  return account;
}

// Return the currently signed-in account, or null when nobody is signed in.
export function getCurrentUser() {
  const email = localStorage.getItem(SESSION_KEY);
  if (!email) return null;
  const account = readAccounts()[email];
  if (!account) return null;
  return { ...account, enrolledCourses: account.enrolledCourses || {} };
}

// Remove the active session without deleting the account itself.
export function logout() {
  localStorage.removeItem(SESSION_KEY);
  console.log("User logged out.");
}

// Update the current user's account object while keeping the same email address as its key.
export function updateCurrentUser(updates) {
  const currentUser = getCurrentUser();
  if (!currentUser) return null;

  const accounts = readAccounts();
  const updatedUser = { ...currentUser, ...updates };
  accounts[currentUser.email] = updatedUser;
  saveAccounts(accounts);
  return updatedUser;
}

// Add a course to the account with zero progress the first time it is enrolled.
export function enrollCourse(courseId) {
  const currentUser = getCurrentUser();
  if (!currentUser) return null;

  const enrolledCourses = {
    ...currentUser.enrolledCourses,
    [courseId]: currentUser.enrolledCourses[courseId] || { progress: 0, completed: false },
  };

  return updateCurrentUser({ enrolledCourses });
}

// Mark only the selected course as complete, leaving every other course unchanged.
export function completeCourse(courseId) {
  const currentUser = getCurrentUser();
  if (!currentUser) return null;

  const enrolledCourses = {
    ...currentUser.enrolledCourses,
    [courseId]: { progress: 100, completed: true },
  };

  return updateCurrentUser({ enrolledCourses });
}
