// Import useNavigate for redirecting after the form is submitted.
import { useNavigate } from "react-router";

// Create the contact page.
function Contact() {
  // Get the navigation function.
  const navigate = useNavigate();
  // Handle the form submission without a browser reload.
  const handleSubmit = (event) => { event.preventDefault(); navigate("/dashboard/courses", { state: { message: "Your enquiry has been received." } }); };

  // Render the contact form.
  return (
    <main className="section narrow-section">
      <p className="eyebrow">Get in touch</p>
      <h1>Contact Tech Academy</h1>
      <form className="contact-form" onSubmit={handleSubmit}>
        <label>Name<input name="name" type="text" required /></label>
        <label>Email<input name="email" type="email" required /></label>
        <label>Message<textarea name="message" rows="6" required /></label>
        <button className="primary-button button-reset" type="submit">Send Message</button>
      </form>
    </main>
  );
}

// Export the Contact page.
export default Contact;
