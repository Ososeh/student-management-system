// Import React tools used to create and share authentication state.
import { createContext, useContext, useState } from "react";
// Import the functions that perform the demo authentication operations.
import { completeCourse, enrollCourse, getCurrentUser, login, logout, signUp } from "./auth";

// Create a context so any component can access the current account without passing it through many props.
const AuthContext = createContext(null);

// Provide authentication information and actions to the entire application.
export function AuthProvider({ children }) {
  // Load the current user once when the provider starts.
  const [user, setUser] = useState(() => getCurrentUser());

  // Create the signup action exposed to child components.
  const createAccount = (details) => {
    const account = signUp(details);
    setUser(account);
    return account;
  };

  // Create the login action exposed to child components.
  const signIn = (email, password) => {
    const account = login(email, password);
    setUser(account);
    return account;
  };

  // Create the logout action exposed to child components.
  const signOut = () => {
    logout();
    setUser(null);
  };

  // Enrol the current user and immediately refresh the React state with the updated account.
  const enrol = (courseId) => {
    const updatedUser = enrollCourse(courseId);
    setUser(updatedUser);
    return updatedUser;
  };

  // Complete one course without changing the progress of other enrolled courses.
  const markCourseComplete = (courseId) => {
    const updatedUser = completeCourse(courseId);
    setUser(updatedUser);
    return updatedUser;
  };

  // Build the value that every descendant component can use for authentication and course actions.
  const value = { user, isAuthenticated: Boolean(user), createAccount, signIn, signOut, enrol, markCourseComplete };

  // Make the authentication value available to every descendant component.
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// Provide a small custom Hook for safely reading the authentication context.
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider.");
  return context;
}
