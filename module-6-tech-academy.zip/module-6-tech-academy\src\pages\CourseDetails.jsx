// Import routing tools for reading the dynamic ID and navigating between pages.
import { Link, useNavigate, useParams } from "react-router";
// Import the course data.
import courses from "../data/courses";
// Import authentication actions.
import { useAuth } from "../auth/AuthContext";

// Create the dynamic course details page.
function CourseDetails() {
  // Read the dynamic courseId from the URL.
  const { courseId } = useParams();
  // Get the programmatic navigation function.
  const navigate = useNavigate();
  // Get authentication status and enrollment action.
  const { isAuthenticated, user, enrol } = useAuth();
  // Convert the URL string to a number and find the matching course.
  const course = courses.find((item) => item.id === Number(courseId));
  // Determine whether this course already belongs to the current user's account.
  const isEnrolled = Boolean(user?.enrolledCourses?.[courseId]);

  // Handle an invalid dynamic identifier rather than crashing.
  if (!course) return <main className="section"><p className="eyebrow">Course Error</p><h1>Course Not Found</h1><p>We could not find a course with that identifier.</p><button className="secondary-button button-reset" onClick={() => navigate("/courses")}>Back to Courses</button></main>;

  // Enrol the student or send a signed-out visitor to the authentication page.
  const handleEnrollment = () => {
    if (!isAuthenticated) {
      navigate("/login", { state: { from: `/courses/${course.id}` } });
      return;
    }
    enrol(course.id);
    navigate("/dashboard/courses");
  };

  // Render the selected course.
  return (
    <main className="section course-details">
      <Link to="/courses" className="back-link">← Back to Courses</Link>
      <p className="eyebrow">{course.category} · {course.level}</p>
      <h1>{course.title}</h1>
      <p>{course.description}</p>
      <div className="detail-grid"><article><strong>Instructor</strong><span>{course.instructor}</span></article><article><strong>Duration</strong><span>{course.duration}</span></article><article><strong>Price</strong><span>{course.price}</span></article></div>
      <section className="content-section"><h2>Topics</h2><ul>{course.topics.map((topic) => <li key={topic}>{topic}</li>)}</ul></section>
      <button className="primary-button button-reset" onClick={handleEnrollment}>{isEnrolled ? "View My Progress" : "Enrol Now"}</button>
    </main>
  );
}

// Export the course details page.
export default CourseDetails;
