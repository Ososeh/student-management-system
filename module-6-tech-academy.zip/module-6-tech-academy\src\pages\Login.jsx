// Import React state for controlled form fields and UI mode changes.
import { useState } from "react";
// Import routing tools for navigation and reading the protected-route redirect.
import { useLocation, useNavigate } from "react-router";
// Import authentication actions from the shared context.
import { useAuth } from "../auth/AuthContext";

// Create the login and signup page.
function Login() {
  // Get the programmatic navigation function.
  const navigate = useNavigate();
  // Read any redirect information supplied by ProtectedRoute.
  const location = useLocation();
  // Read the authentication actions.
  const { createAccount, signIn } = useAuth();
  // Track whether the page is currently showing signup or login.
  const [isSignUp, setIsSignUp] = useState(false);
  // Store every signup/login input as controlled React state.
  const [form, setForm] = useState({ firstName: "", lastName: "", email: "", password: "", confirmPassword: "" });
  // Store a user-friendly error message.
  const [error, setError] = useState("");
  // Store a message explaining why the user was redirected to login.
  const [notice, setNotice] = useState(location.state?.from ? "Please log in or create an account to access your dashboard." : "");

  // Update only the field that the user is currently typing into.
  const handleChange = (event) => {
    setForm((currentForm) => ({ ...currentForm, [event.target.name]: event.target.value }));
  };

  // Process either the signup or login form.
  const handleSubmit = (event) => {
    event.preventDefault();
    setError("");
    try {
      if (isSignUp) {
        if (form.password !== form.confirmPassword) throw new Error("The passwords do not match.");
        createAccount(form);
        console.log("Signup successful.");
      } else {
        signIn(form.email, form.password);
        console.log("Login successful.");
      }
      const target = location.state?.from?.startsWith("/dashboard") ? location.state.from : "/dashboard";
      navigate(target, { replace: true });
    } catch (submissionError) {
      console.error("Authentication error:", submissionError);
      setError(submissionError.message);
    }
  };

  // Switch between login and signup modes and clear old messages.
  const switchMode = () => {
    setIsSignUp((currentMode) => !currentMode);
    setError("");
    setNotice("");
    setForm({ firstName: "", lastName: "", email: "", password: "", confirmPassword: "" });
  };

  // Render the authentication form while preserving the existing visual language.
  return (
    <main className="section narrow-section">
      <p className="eyebrow">Student Access</p>
      <h1>{isSignUp ? "Create Your Account" : "Log In"}</h1>
      <p>{isSignUp ? "Create your student account before entering the Tech Academy dashboard." : "Log in to continue to your student dashboard."}</p>
      {notice && <p className="success-message" role="status">{notice}</p>}
      {error && <p className="error-message" role="alert">{error}</p>}
      <form className="contact-form" onSubmit={handleSubmit}>
        {isSignUp && (
          <>
            <label>First Name<input name="firstName" type="text" value={form.firstName} onChange={handleChange} required /></label>
            <label>Last Name<input name="lastName" type="text" value={form.lastName} onChange={handleChange} required /></label>
          </>
        )}
        <label>Email Address<input name="email" type="email" value={form.email} onChange={handleChange} required /></label>
        <label>Password<input name="password" type="password" value={form.password} onChange={handleChange} required /></label>
        {isSignUp && <label>Confirm Password<input name="confirmPassword" type="password" value={form.confirmPassword} onChange={handleChange} required /></label>}
        <button type="submit" className="primary-button button-reset">{isSignUp ? "Create Account" : "Log In"}</button>
      </form>
      <p className="auth-switch">
        {isSignUp ? "Already have an account?" : "New student?"}{" "}
        <button type="button" className="text-button" onClick={switchMode}>{isSignUp ? "Log In" : "Create an Account"}</button>
      </p>
    </main>
  );
}

// Export the authentication page.
export default Login;
