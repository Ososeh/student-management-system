// Import Link for internal navigation to the course catalogue.
import { Link } from "react-router";

// Create the Tech Academy home page.
function Home() {
  // Return the page content.
  return (
    <main>
      <section className="hero-section">
        <div>
          <p className="eyebrow">Technology Education</p>
          <h1>Build practical technology skills.</h1>
          <p>Learn through structured classes, practical exercises, mentorship, and real-world projects.</p>
          <div className="hero-actions"><Link to="/courses" className="primary-button">Explore Courses</Link><Link to="/about" className="secondary-button">About Tech Academy</Link></div>
        </div>
      </section>
      <section className="section">
        <p className="eyebrow">Why Tech Academy?</p>
        <h2>Learning built around practice.</h2>
        <div className="feature-grid">
          <article className="feature-card"><h3>Practical Learning</h3><p>Apply concepts through exercises and projects.</p></article>
          <article className="feature-card"><h3>Expert Support</h3><p>Receive guidance from experienced instructors.</p></article>
          <article className="feature-card"><h3>Career Preparation</h3><p>Develop a portfolio and prepare for employment and freelance opportunities.</p></article>
        </div>
      </section>
    </main>
  );
}

// Export the home page.
export default Home;
