# Module 6 Tech Academy — Corrected Mini-Project

This is the corrected Vite + React JavaScript version of the Module 6 Routing and Navigation mini-project.

## Start the project

```bash
npm install
npm run dev
```

## Main improvements

- Login and signup are the first experience at `/` for signed-out users.
- Dashboard routes are protected.
- Accounts contain first name, last name, email, password, and independent course-progress records.
- Profile and dashboard identity are generated from the current account.
- Course enrollment starts at 0%.
- Each enrolled course has independent progress.
- A course can be marked complete and becomes 100% complete.
- Logout clears the active session but keeps the account record.
- Existing visual styling and component folders are preserved.

See `TEST_REPORT.md` for the identified issues, corrections, validation performed, and the frontend-demo security limitation.


## Deployment configuration

- Added `vercel.json` with a Vercel rewrite so direct visits or refreshes on React Router URLs such as `/courses/1` and `/dashboard/profile` are served by `index.html`, allowing React Router to handle the route in the browser.
- Added `public/.htaccess` for Apache/cPanel hosting compatibility. Vercel does **not** use `.htaccess`; the Vercel-specific configuration is `vercel.json`. Vite copies files from `public/` into the production output.

### Vercel deployment

Deploy the project from the folder containing `package.json` and `vercel.json`. The build command is `npm run build`, and Vercel should serve the generated Vite output. The rewrite in `vercel.json` is especially important for browser refreshes or direct links to client-side routes.
