// Create the shared footer displayed beneath public pages.
function Footer() {
  // Return simple footer content.
  return <footer className="app-footer"><p>Tech Academy · Module 6 Routing and Navigation practice</p></footer>;
}

// Export the footer for the public layout.
export default Footer;
