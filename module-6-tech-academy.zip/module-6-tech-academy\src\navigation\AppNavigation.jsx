// Import navigation components from React Router.
import { NavLink } from "react-router";
// Import authentication state so the menu can show the correct links.
import { useAuth } from "../auth/AuthContext";

// Build the public navigation bar without exposing protected dashboard links to signed-out users.
function AppNavigation() {
  // Read the current authentication status.
  const { isAuthenticated } = useAuth();
  // Build the active-link class once for all navigation items.
  const getLinkClass = ({ isActive }) => (isActive ? "navbar-link active" : "navbar-link");

  // Return the navigation links.
  return (
    <nav className="navbar" aria-label="Primary navigation">
      <NavLink to="/home" end className={getLinkClass}>Home</NavLink>
      <NavLink to="/about" className={getLinkClass}>About</NavLink>
      <NavLink to="/courses" className={getLinkClass}>Courses</NavLink>
      <NavLink to="/contact" className={getLinkClass}>Contact</NavLink>
      {isAuthenticated ? <NavLink to="/dashboard" className={getLinkClass}>Dashboard</NavLink> : <NavLink to="/login" className={getLinkClass}>Login / Sign Up</NavLink>}
    </nav>
  );
}

// Export the navigation component.
export default AppNavigation;
