# Module 6 — Further Project Information Extracted from the PDF

## Project testing checklist

The PDF asks students to test:

1. Home route displays correctly.
2. All navigation links work.
3. Active link changes correctly.
4. Courses page displays all courses.
5. Course filters update the URL.
6. Each course card opens the correct dynamic page.
7. Invalid course IDs display a friendly message.
8. Back button returns to the previous page.
9. Contact form redirects after submission.
10. Login page redirects to the dashboard.
11. Dashboard child links render inside the dashboard layout.
12. Dashboard index route appears at `/dashboard`.
13. Browser back and forward work.
14. Unknown addresses display the 404 page.
15. Refreshing nested URLs works after deployment fallback configuration.
16. Layout responds correctly on mobile screens.

## Optional improvements listed by the PDF

- Protected routes
- Authentication state
- Admin routes
- Instructor profiles
- Dynamic instructor pages
- Course category pages
- Search functionality
- Pagination
- Breadcrumb navigation
- Scroll restoration
- Route loading indicators
- Lazy-loaded page components
- Student registration page
- Checkout route
- Course lesson routes
- Video classroom routes
- URL-based tabs
- Mobile navigation menu
- Role-based dashboards

## Guided classroom activities

### 1. Basic Website Router
Routes: `/`, `/about`, `/services`, `/contact`. Include navigation, active styles and a custom 404.

### 2. Student Directory
Routes: `/students` and `/students/:studentId`. Each student has ID, name, course, level, email and biography. Use `useParams` for the selected profile.

### 3. Nested Admin Dashboard
Routes: `/admin`, `/admin/users`, `/admin/courses`, `/admin/settings`. Share sidebar, header, main content and logout button. Use nested routes, Outlet, index route and relative NavLink components.

### 4. Product Filters
Use query parameters such as `/products?category=laptops`, `/products?category=phones`, and `/products?category=accessories`. Read the category from the URL, filter products, update the URL and display a no-match message.

## Practical exercises

### Exercise 1 — Bookstore Router
Create `/`, `/books`, `/books/:bookId`, `/about`, and `/contact`. Book details should include title, author, price, description and a back button.

### Exercise 2 — Employee Directory
Create `/employees` and `/employees/:employeeId`. Each employee contains ID, full name, department, position, email and biography. Use `useParams`.

### Exercise 3 — User Dashboard
Create `/account`, `/account/orders`, `/account/profile`, and `/account/security`. Include shared sidebar, nested routes, index route, active links, Outlet and logout navigation.

### Exercise 4 — Category Filters
Support `/products?category=all`, `/products?category=computers`, `/products?category=phones`, and `/products?category=accessories` with `useSearchParams`.

### Exercise 5 — Registration Redirect
After registration, use:

```js
navigate("/welcome", {
  state: {
    name: formData.name,
  },
});
```

The welcome page should display the name using `useLocation`.

## Module assessment areas

The PDF contains 35 theory questions covering routing, BrowserRouter, Routes, Route, Link, NavLink, `end`, programmatic navigation, dynamic routes, `useParams`, nested routes, Outlet, index routes, layout routes, relative links, wildcard routes, Navigate, query parameters, `useSearchParams`, deployment refresh behaviour, route organisation, invalid identifiers, static vs dynamic routes, duplicated navigation logic and shared layouts.

## Coding assessment

Build a Multi-Page Online Store with:

### Public routes
- `/`
- `/products`
- `/products/:productId`
- `/about`
- `/contact`
- `/login`

### Account routes
- `/account`
- `/account/orders`
- `/account/profile`
- `/account/settings`

Required features: BrowserRouter, Routes, static and dynamic routes, nested route group, index route, shared public and account layouts, Link, NavLink, active styles, useParams, useNavigate, Outlet, useSearchParams, product-category filters, custom 404 and responsive styling.

## Take-home assignment

Build a Multi-Page Learning Platform with:

- `/`
- `/about`
- `/courses`
- `/courses/:courseId`
- `/instructors`
- `/instructors/:instructorId`
- `/contact`
- `/login`
- `/dashboard`
- `/dashboard/courses`
- `/dashboard/profile`
- `/dashboard/settings`

Minimum requirements include at least eight page components, public and dashboard layouts, responsive navigation, active navigation styles, at least two dynamic route patterns, nested routing, index route, custom 404, programmatic navigation, query filtering, invalid-resource handling, reusable cards, responsive CSS and appropriate folder organisation.

Advanced requirements listed by the PDF include authentication simulation, protected routes, role-based navigation, admin dashboard, breadcrumbs, course search, pagination, route-level loading indicators, lazy-loaded pages, course checkout, lesson routes, student progress pages, mobile menu, theme switcher and persistent login state.

## Deployment note

The PDF warns that refreshing a nested URL such as `/dashboard/profile` can produce a server 404 if the hosting provider is not configured to send the SPA entry HTML file for application routes. The exact fallback configuration depends on the hosting platform.
