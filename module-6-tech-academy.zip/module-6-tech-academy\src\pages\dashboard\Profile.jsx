// Import the authenticated student account.
import { useAuth } from "../../auth/AuthContext";

// Create the student profile page.
function Profile() {
  // Read the live account instead of using placeholder profile information.
  const { user } = useAuth();
  // Build the student's full name from the stored first and last names.
  const fullName = `${user.firstName} ${user.lastName}`;
  // Create initials for the profile avatar.
  const initials = `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();

  // Return the authenticated student's actual profile information.
  return (
    <div>
      <p className="eyebrow">Account</p>
      <h1>Student Profile</h1>
      <div className="profile-card">
        <div className="profile-avatar">{initials}</div>
        <div>
          <h2>{fullName}</h2>
          <p><strong>First name:</strong> {user.firstName}</p>
          <p><strong>Last name:</strong> {user.lastName}</p>
          <p><strong>Email:</strong> {user.email}</p>
          <p>Frontend Development Student</p>
        </div>
      </div>
    </div>
  );
}

// Export the profile page.
export default Profile;
