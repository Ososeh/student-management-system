// Create the About page.
function About() {
  // Return information about the academy.
  return (
    <main className="section">
      <p className="eyebrow">About Tech Academy</p>
      <h1>Technology education built around practical experience.</h1>
      <p>Tech Academy helps students develop relevant digital and technical skills through structured classes, practical activities, mentorship, and projects.</p>
      <section className="content-section"><h2>Our Mission</h2><p>Our mission is to make practical technology education accessible to students, professionals, and business owners.</p></section>
      <section className="content-section"><h2>Our Training Approach</h2><ul><li>Instructor-led learning</li><li>Practical exercises</li><li>Real-world projects</li><li>Progress assessments</li><li>Portfolio development</li></ul></section>
    </main>
  );
}

// Export the About page.
export default About;
