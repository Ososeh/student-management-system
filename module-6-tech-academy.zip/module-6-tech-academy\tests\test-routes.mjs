import fs from "node:fs";
import assert from "node:assert/strict";

const read = (file) => fs.readFileSync(file, "utf8");
const app = read("src/App.jsx");
const auth = read("src/auth/auth.js");
const authContext = read("src/auth/AuthContext.jsx");
const login = read("src/pages/Login.jsx");
const coursePage = read("src/pages/CourseDetails.jsx");
const coursesPage = read("src/pages/Courses.jsx");
const dashboard = read("src/layouts/DashboardLayout.jsx");
const dashboardHome = read("src/pages/dashboard/DashboardHome.jsx");
const myCourses = read("src/pages/dashboard/MyCourses.jsx");
const profile = read("src/pages/dashboard/Profile.jsx");
const main = read("src/main.jsx");

for (const path of ["about", "home", "courses", "courses/:courseId", "contact", "login", "dashboard"]) {
  assert.ok(app.includes(`path="${path}"`), `Missing route: ${path}`);
}
assert.ok(app.includes("<Route index element={<StartRedirect />}"), "Root startup redirect missing");
assert.ok(app.includes("<Route element={<ProtectedRoute />}>"), "Protected route wrapper missing");
assert.ok(app.includes("<Route index element={<DashboardHome />}") && app.includes("path=\"courses\" element={<MyCourses />"), "Missing dashboard child routes");
assert.ok(app.includes("path=\"*\""), "Missing wildcard 404 route");
assert.ok(app.includes("<PublicLayout />") && app.includes("<DashboardLayout />"), "Missing layouts");
assert.ok(coursePage.includes("useParams") && coursePage.includes("Number(courseId)"), "Dynamic parameter handling missing");
assert.ok(coursesPage.includes("useSearchParams") && coursesPage.includes("setSearchParams"), "Query filtering missing");
assert.ok(dashboard.includes("<Outlet />") && dashboard.includes("signOut") && dashboard.includes("user.firstName"), "Dashboard authentication handling missing");
assert.ok(main.includes("<BrowserRouter>") && main.includes("<AuthProvider>") && main.includes("<App />"), "Provider setup missing");
assert.ok(login.includes("firstName") && login.includes("lastName") && login.includes("confirmPassword") && login.includes("createAccount") && login.includes("signIn"), "Login/signup fields or actions missing");
assert.ok(auth.includes("enrolledCourses: {}") && auth.includes("progress: 0") && auth.includes("progress: 100") && auth.includes("completed: true"), "Independent course progress logic missing");
assert.ok(myCourses.includes("markCourseComplete") && myCourses.includes("progress.progress"), "Course progress UI missing");
assert.ok(dashboardHome.includes("overallProgress") && dashboardHome.includes("user.firstName") && dashboardHome.includes("completedCourses"), "Personalised dashboard statistics missing");
assert.ok(profile.includes("user.firstName") && profile.includes("user.lastName") && profile.includes("user.email"), "Personalised profile information missing");
assert.ok(authContext.includes("AuthContext.Provider") && authContext.includes("setUser"), "Authentication context missing");
console.log("All Module 6 authentication, routing, profile, enrollment, and progress checks passed.");
