// Import routing tools for nested dashboard navigation and rendering.
import { NavLink, Outlet, useNavigate } from "react-router";
// Import the authenticated user and logout action.
import { useAuth } from "../auth/AuthContext";

// Create the shared dashboard layout required by the mini-project.
function DashboardLayout() {
  // Get the function that changes the current route programmatically.
  const navigate = useNavigate();
  // Get the authenticated account and logout action.
  const { user, signOut } = useAuth();
  // Create one reusable function for active dashboard link styling.
  const getLinkClass = ({ isActive }) => (isActive ? "dashboard-link active" : "dashboard-link");
  // Define the logout action demonstrated in the PDF.
  const handleLogout = () => {
    signOut();
    navigate("/login", { replace: true });
  };

  // Return the dashboard sidebar and the location where child pages appear.
  return (
    <main className="dashboard-layout">
      <aside className="dashboard-sidebar">
        <h2>Student Portal</h2>
        <p className="dashboard-user">{user.firstName} {user.lastName}</p>
        <nav aria-label="Dashboard navigation">
          <NavLink to="/dashboard" end className={getLinkClass}>Overview</NavLink>
          <NavLink to="courses" className={getLinkClass}>My Courses</NavLink>
          <NavLink to="profile" className={getLinkClass}>Profile</NavLink>
          <NavLink to="settings" className={getLinkClass}>Settings</NavLink>
        </nav>
        <button className="logout-button" onClick={handleLogout}>Log Out</button>
      </aside>
      <section className="dashboard-content"><Outlet /></section>
    </main>
  );
}

// Export the dashboard layout.
export default DashboardLayout;
