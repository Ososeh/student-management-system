// Import course data and authentication actions.
import courses from "../../data/courses";
import { useAuth } from "../../auth/AuthContext";

// Create the enrolled courses page with independent progress controls.
function MyCourses() {
  // Read the current account and course completion action.
  const { user, markCourseComplete } = useAuth();
  // Convert the saved enrollment object into a list of course records.
  const enrolledCourses = Object.entries(user.enrolledCourses).map(([courseId, progress]) => ({
    course: courses.find((item) => item.id === Number(courseId)),
    progress,
  })).filter((item) => item.course);

  // Render enrolled courses and their individual progress.
  return (
    <div>
      <p className="eyebrow">Learning</p>
      <h1>My Courses</h1>
      {enrolledCourses.length === 0 ? <p className="empty-message">You have not enrolled in a course yet.</p> : enrolledCourses.map(({ course, progress }) => (
        <article className="dashboard-course" key={course.id}>
          <h2>{course.title}</h2>
          <p>Progress: {progress.progress}%</p>
          <progress value={progress.progress} max="100" aria-label={`${course.title} progress`} />
          {progress.completed ? <p className="success-message">Course completed ✓</p> : <button className="primary-button button-reset" onClick={() => markCourseComplete(course.id)}>Mark as Complete</button>}
        </article>
      ))}
    </div>
  );
}

// Export the enrolled courses page.
export default MyCourses;
