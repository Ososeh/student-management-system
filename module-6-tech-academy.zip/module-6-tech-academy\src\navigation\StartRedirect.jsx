// Import Navigate so the application can choose the correct first page.
import { Navigate } from "react-router";
// Import the current authentication state.
import { useAuth } from "../auth/AuthContext";

// Decide where the root URL should send the visitor.
function StartRedirect() {
  // Check whether a saved authenticated session exists.
  const { isAuthenticated } = useAuth();
  // New visitors must authenticate first; authenticated users can continue to their dashboard.
  return <Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />;
}

// Export the startup redirect.
export default StartRedirect;
