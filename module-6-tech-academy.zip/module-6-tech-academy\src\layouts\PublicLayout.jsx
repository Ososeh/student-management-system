// Import Outlet so child public routes can appear inside this shared layout.
import { Link, Outlet } from "react-router";
// Import the shared public navigation bar.
import Navbar from "../components/Navbar";
// Import the shared public footer.
import Footer from "../components/Footer";

// Create the public layout required by the Module 6 mini-project.
function PublicLayout() {
  // Return the shared shell around all public pages.
  return (
    <div className="application">
      <header className="site-header">
        <Link className="site-logo" to="/home">Tech <span>Academy</span></Link>
        <Navbar />
      </header>
      <div className="page-container"><Outlet /></div>
      <Footer />
    </div>
  );
}

// Export the layout.
export default PublicLayout;
