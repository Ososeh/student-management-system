// Import Navigate so unauthenticated users can be redirected away from protected pages.
import { Navigate, Outlet, useLocation } from "react-router";
// Import the current authentication state.
import { useAuth } from "../auth/AuthContext";

// Protect every route placed inside this component.
function ProtectedRoute() {
  // Read whether a user is currently authenticated.
  const { isAuthenticated } = useAuth();
  // Remember where the user tried to go so the login page can explain the redirect.
  const location = useLocation();

  // Send unauthenticated visitors to the login page instead of rendering protected content.
  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  // Render the requested protected child route when authentication exists.
  return <Outlet />;
}

// Export the route guard for App.jsx.
export default ProtectedRoute;
