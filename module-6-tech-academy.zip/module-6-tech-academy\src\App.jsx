// Import the route declaration components from React Router.
import { Route, Routes } from "react-router";
// Import the shared layouts.
import PublicLayout from "./layouts/PublicLayout";
import DashboardLayout from "./layouts/DashboardLayout";
// Import the route guard.
import ProtectedRoute from "./navigation/ProtectedRoute";
import StartRedirect from "./navigation/StartRedirect";
// Import public pages.
import About from "./pages/About";
import Contact from "./pages/Contact";
import CourseDetails from "./pages/CourseDetails";
import Courses from "./pages/Courses";
import Home from "./pages/Home";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
// Import dashboard pages.
import DashboardHome from "./pages/dashboard/DashboardHome";
import MyCourses from "./pages/dashboard/MyCourses";
import Profile from "./pages/dashboard/Profile";
import Settings from "./pages/dashboard/Settings";

// Keep App focused on route configuration while the page components contain the actual application logic.
function App() {
  // Define all application URLs and their corresponding components.
  return (
    <Routes>
      <Route element={<PublicLayout />}>
        <Route index element={<StartRedirect />} />
        <Route path="home" element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="courses" element={<Courses />} />
        <Route path="courses/:courseId" element={<CourseDetails />} />
        <Route path="contact" element={<Contact />} />
        <Route path="login" element={<Login />} />
        <Route element={<ProtectedRoute />}>
          <Route path="dashboard" element={<DashboardLayout />}>
            <Route index element={<DashboardHome />} />
            <Route path="courses" element={<MyCourses />} />
            <Route path="profile" element={<Profile />} />
            <Route path="settings" element={<Settings />} />
          </Route>
        </Route>
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}

// Export App so main.jsx can render it.
export default App;
