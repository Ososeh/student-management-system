// Create the account settings page.
function Settings() {
  // Return the preference controls.
  return (
    <div><p className="eyebrow">Preferences</p><h1>Account Settings</h1><form className="settings-form"><label>Email Notifications<input type="checkbox" defaultChecked /></label><label>Course Reminders<input type="checkbox" defaultChecked /></label><label>Weekly Progress Report<input type="checkbox" /></label></form></div>
  );
}

// Export the settings page.
export default Settings;
